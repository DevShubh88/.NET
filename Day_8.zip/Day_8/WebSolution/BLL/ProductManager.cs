﻿namespace BLL;
using BOL;
using DAL;
public class ProductManager
{
    public List<Product> GetAllProducts(){
        DBManager db = new DBManager();
        List<Product> allProducts = new List<Product>();
        allProducts=db.GetAllProducts();
        return allProducts;
    }
    public void InsertData(int pid,string pnm,int qty,double price)
    {
        DBManager db = new DBManager();
        db.InsertData(pid,pnm,qty,price);
    }
}

 