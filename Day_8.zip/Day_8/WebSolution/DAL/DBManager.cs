﻿namespace DAL;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager
{

    public static string conString = @"server=192.168.10.150;port=3306;user=dac59; password=welcome;database=dac59";
    public  List<Product> GetAllProducts()
    {
        List<Product> allproducts = new List<Product>();
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "SELECT * FROM product1";
        // string query1 = "insert into Product values(5, 'kivi', 5, 50)";
        try
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                int pid = int.Parse(reader["pid"].ToString());
                string pname = reader["pnm"].ToString();
                int quantity = int.Parse(reader["qty"].ToString());
                double price = double.Parse(reader["price"].ToString());

                Product prd = new Product(pid,pname,quantity,price);
                allproducts.Add(prd);
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
        return allproducts;
    }
    public void InsertData(int pid, string pnm, int qty, double price)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        string query = "insert into product1 values(@pid,@pnm,@qty,@price)";
        MySqlCommand cmd = new MySqlCommand(query,con);
        try
        {
            con.Open();
           
           cmd.Parameters.AddWithValue("@pid",pid);
           cmd.Parameters.AddWithValue("@pnm",pnm);
           cmd.Parameters.AddWithValue("@qty",qty);
            cmd.Parameters.AddWithValue("@price",price);
            cmd.ExecuteNonQuery();
            
        }catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            con.Close();
        }
    }
}

