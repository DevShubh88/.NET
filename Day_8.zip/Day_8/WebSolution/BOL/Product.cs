namespace BOL;

public class Product
{
    public int id{
       get;
        set;
    }
    public string pnm{
         get;
        set;
    }
    public int qty{
         get;
        set;
    }
    public double price{
         get;
        set;
    }

    public Product()
    {
        // this.id = 1;
        // this.pnm = "pname";
        // this.qty = "quant";
        // this.price = "currency";
    }
    public Product(int productId, string pname, int quant, double currency)
    {
        this.id = productId;
        this.pnm = pname;
        this.qty = quant;
        this.price = currency;
    }
}