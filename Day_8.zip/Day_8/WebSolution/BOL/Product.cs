namespace BOL;

public class Product
{
    public int pid { get; set; }
    public string pnm { get; set; }
    public int qty { get; set; }
    public double price { get; set; }

    public Product()
    {
        // this.id = 1;
        // this.pnm = "pname";
        // this.qty = "quant";
        // this.price = "currency";
    }
    public Product(int pid, string pname, int quant, double currency)
    {
        this.pid = pid;
        this.pnm = pname;
        this.qty = quant;
        this.price = currency;
    }
}